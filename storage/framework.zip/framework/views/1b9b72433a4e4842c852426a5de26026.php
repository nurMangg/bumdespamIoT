<?php
    $settingWeb = \App\Models\SettingWeb::first();

?>
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e($settingWeb->settingWebNama ? $settingWeb->settingWebNama . ' | PDAM' : env('APP_NAME')); ?></title>
        <link rel="shortcut icon" href="<?php echo e($settingWeb->settingWebLogo ? asset($settingWeb->settingWebLogo) : asset('images/favicon.svg')); ?>" type="image/x-icon">
        <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">


        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
        <style>
            body {
                transition: background-image 0.5s ease-in-out;
            }

            @media only screen and (max-width: 767px) {
                .min-h-screen {
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    justify-content: center;
                }
            }
        </style>
    </head>
    <body class="font-sans text-gray-900 antialiased bg-cover bg-center bg-no-repeat">
        <div class="min-h-screen flex flex-col sm:justify-center items-center px-4 sm:px-6 lg:px-8">
            

            <div class="w-full sm:max-w-md mt-6 px-6 py-4 bg-white bg-opacity-50 shadow-md overflow-hidden sm:rounded-lg" data-aos="fade-up" data-aos-duration="2000" style="border-radius: 0.5rem;">
                <div class="flex flex-col items-center justify-center mb-4 animate-fade-in-down">
                    <a href="/">
                        <?php if (isset($component)) { $__componentOriginal8892e718f3d0d7a916180885c6f012e7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8892e718f3d0d7a916180885c6f012e7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.application-logo','data' => ['class' => 'fill-current text-gray-500 w-48 h-48 animate-spin-slow']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('application-logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'fill-current text-gray-500 w-48 h-48 animate-spin-slow']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8892e718f3d0d7a916180885c6f012e7)): ?>
<?php $attributes = $__attributesOriginal8892e718f3d0d7a916180885c6f012e7; ?>
<?php unset($__attributesOriginal8892e718f3d0d7a916180885c6f012e7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8892e718f3d0d7a916180885c6f012e7)): ?>
<?php $component = $__componentOriginal8892e718f3d0d7a916180885c6f012e7; ?>
<?php unset($__componentOriginal8892e718f3d0d7a916180885c6f012e7); ?>
<?php endif; ?>
                    </a>
                    <p class="text-center text-sm text-gray-600 mt-2">
                        <?php echo e($settingWeb->settingWebAlamat ? $settingWeb->settingWebAlamat : ''); ?>

                    </p>
                </div>
                <?php echo e($slot); ?>

            </div>
        </div>

        <!-- Random Background Script -->
        <script>
            document.addEventListener('DOMContentLoaded', () => {
                // Daftar gambar background
                const backgrounds = [
                    "<?php echo e(asset('images/873.jpg')); ?>",
                    "<?php echo e(asset('images/9126.jpg')); ?>",
                    "<?php echo e(asset('images/24143.jpg')); ?>",
                    "<?php echo e(asset('images/46361.jpg')); ?>"
                ];

                // Pilih gambar secara acak
                const randomBackground = backgrounds[Math.floor(Math.random() * backgrounds.length)];

                // Terapkan gambar ke body
                document.body.style.backgroundImage = `url('${randomBackground}')`;
            });
        </script>
        <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
        <script>
            AOS.init();
          </script>
    </body>
</html>

<?php /**PATH /home/mangg/Documents/pdam-bumdes/resources/views/layouts/guest.blade.php ENDPATH**/ ?>