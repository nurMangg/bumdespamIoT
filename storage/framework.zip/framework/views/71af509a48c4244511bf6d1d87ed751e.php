<?php
    $settingLogo = \App\Models\SettingWeb::first();
?>

<img src="<?php echo e(asset('images/logolandscape.png')); ?>"  width="350" height="140">



<?php /**PATH /home/mangg/Documents/pdam-bumdes/resources/views/components/application-logo.blade.php ENDPATH**/ ?>