<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-left">
                <li class="breadcrumb-item"><a href="#"><?php echo e($breadcrumb ?? env('APP_NAME')); ?></a></li>
                <li class="breadcrumb-item active"><?php echo e($title ?? env('APP_NAME')); ?></li>
              </ol>
          </div><!-- /.col -->
          <div class="col-sm-6">
            
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container mb-3">
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Transaksi</h3>
            <div class="card-tools">
              <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                <i class="fas fa-minus"></i>
              </button>
              <button type="button" class="btn btn-tool" onclick="getInfoAllTransaksi()" title="Refresh">
                <i class="fas fa-sync-alt"></i>
              </button>
          </div>
          </div>
          <!-- /.card-header -->
          <div class="card-body">
            <div class="row">
              <div class="col-md-12">
                <div class="alert alert-primary alert-dismissible">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                  <h5><i class="icon fas fa-exclamation-triangle"></i> Informasi!</h5>
                  <ul>
                    <li>Data yang disini merupakan data tagihan pembayaran yang menggunakan transfer manual, bukan data tagihan pembayaran semuanya atau yang menggunakan transfer otomatis</li>
                
                  </ul>
                </div>
              </div>
              <div class="col-12 col-sm-6 col-md-6">
                <div class="info-box">
                  <span class="info-box-icon bg-danger elevation-1"><i class="fas fa-money-bill-wave"></i></span>
    
                  <div class="info-box-content">
                    <span class="info-box-text">Total Tagihan Pending Melalui Transfer Manual</span>
                    <span class="info-box-number" id="totalTagihanBelumLunasSemua">
                      <small></small>
                    </span>
                  </div>
                  <!-- /.info-box-content -->
                </div>
                <!-- /.info-box -->
              </div>
              <!-- /.col -->
              <div class="col-12 col-sm-6 col-md-6">
                <div class="info-box mb-3">
                  <span class="info-box-icon bg-success elevation-1"><i class="fas fa-money-bill-wave"></i></span>
    
                  <div class="info-box-content">
                    <span class="info-box-text" data-toggle="tooltip" data-placement="top">Total Tagihan Approved Melalui Transfer Manual</span>
                    <span class="info-box-number" id="totalTagihanLunasSemua"></span>
                  </div>
                  <!-- /.info-box-content -->
                </div>
                <!-- /.info-box -->
              </div>
              <!-- /.col -->
    
              <!-- fix for small devices only -->
              <div class="clearfix hidden-md-up"></div>
            </div>
          </div>
          <!-- /.card-body -->
        </div>
      </div>
      <div class="container">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Daftar <?php echo e($title ?? env('APP_NAME')); ?></h3>
                
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table class="table" id="laravel_datatable">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <?php $__currentLoopData = $grid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th><?php echo e($item['label']); ?></th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <th>Action</th>
                        </tr>
                    </thead>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->

</div>

<div class="modal fade" id="buktiModal" tabindex="-1" role="dialog" aria-labelledby="buktiModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Bukti Pembayaran</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body text-center">
                <img id="bukti" src="" class="img-fluid" />
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function () {

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });


        $('#laravel_datatable').DataTable({
            processing: true,
            serverSide: true,
            ajax: {
                url: '<?php echo e(route($route . '.index')); ?>',
                type: 'GET',
                dataType: 'json',
                error: function (xhr, status, error) {
                    console.error('AJAX Error: ' + status + error);
                }
            },
            columns: [
              {
                data: 'id',
                name: 'id',
                render: function (data, type, row, meta) {
                    return meta.row + 1;
                }
              },
              <?php $__currentLoopData = $grid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  {data: '<?php echo e($field['field']); ?>', name: '<?php echo e($field['field']); ?>'},
                  
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
              {data: 'action', name: 'action', orderable: false, searchable: false},
            ],
            order: [[0, 'desc']],
            responsive: true,
            scrollX: true,
        });

        $('body').on('click', '.konfirmasi', function () {
            var id = $(this).data('pembayaran');
            $('#konfirmasi').prop('disabled', true);

            Swal.fire({
                title: 'Konfirmasi',
                text: "Apakah Sudah benar benar di cek datanya?",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Ya, konfirmasi'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: "<?php echo e(route($route . '.store')); ?>/",
                        type: 'POST',
                        dataType: 'json',
                        data: {
                            pembayaranId: id
                        },
                        success: function (response) {
                            $('#konfirmasi').prop('disabled', false);

                            if (response.status == 'success') {
                                toastr.success(response.message);
                                setTimeout(function() {
                                    console.log('Timeout executed');
                                    window.location.reload();
                                }, 1000);
                            } else {
                                toastr.error(response.message);
                            }
                            
                        },
                        error: function (xhr) {
                            toastr.error("Pembayaran Sudah Ada!, Selesaikan Pembayaran");
                            toastr.error(xhr.responseText)
                            $('#konfirmasi').prop('disabled', false);
                        }
                    });
                        
                } else {
                    $('#konfirmasi').prop('disabled', false);
                }
            });
        });

        $('body').on('click', '.lihat-foto', function () {
            var id = $(this).data('id');
            $('#bukti').attr('src', id);
            $('#buktiModal').modal('show');
        });

        getInfoAllTransaksi();



    })

    function getInfoAllTransaksi() {
        $.ajax({
            url: '<?php echo e(route( $route . '.getInfoAllTrxManual')); ?>',
            type: 'GET',
            dataType: 'json',
            success: function(response) {
              console.log(response);
                $('#totalTagihanBelumLunasSemua').html('Rp. ' + response.totalSemuaTagihanBelumLunas.toLocaleString('id-ID') + ' / ' + response.jumlahTagihanBelumLunas + ' Tagihan');
                $('#totalTagihanLunasSemua').html('Rp. ' + response.totalSemuaTagihanLunas.toLocaleString('id-ID') + ' / ' + response.jumlahTagihanLunas + ' Tagihan');
            },
            error: function(xhr) {
                console.error('AJAX Error: ' + xhr.status + xhr.statusText);
            }
        });

        $('#laravel_datatable').DataTable().ajax.reload(null, false);

    }    

    
     
</script>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mangg/Documents/pdam-bumdes/resources/views/transaksis/index2.blade.php ENDPATH**/ ?>