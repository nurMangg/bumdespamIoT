<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-left">
                <li class="breadcrumb-item"><a href="#"><?php echo e($breadcrumb ?? env('APP_NAME')); ?></a></li>
                <li class="breadcrumb-item active"><?php echo e($title ?? env('APP_NAME')); ?></li>
              </ol>
          </div><!-- /.col -->
          <div class="col-sm-6">
            
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
        <div class="container mb-3">
            
        </div>
      <div class="container">
        <div class="row">
          <?php if(Auth::user()->userRoleId != App\Models\Roles::where('roleName', 'pelanggan')->first()->roleId): ?>
          <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                  <h3 class="card-title"><?php echo e(__('Filter Data')); ?></h3>
                  <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                      <i class="fas fa-minus"></i>
                    </button>
                    <button type="button" class="btn btn-tool" onclick="location.reload()" title="Refresh">
                      <i class="fas fa-sync-alt"></i>
                    </button>
                </div>
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                  
                  <form>
                    <div class="row">
                    <?php $__currentLoopData = $form; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-group mb-3 col-md-<?php echo e($field['width'] ?? 12); ?>">
                      <label for="<?php echo e($field['field']); ?>" class="control-label">
                          <?php echo e($field['label']); ?>

                      </label>
                      <?php if($field['type'] === 'checkbox'): ?>
                      
                          <?php $__currentLoopData = $field['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          
                              <div class="form-check">
                                  <input class="form-check-input" type="checkbox" id="<?php echo e($field['field']); ?>-<?php echo e($value); ?>" name="<?php echo e($field['field']); ?>[]" value="<?php echo e($value); ?>" <?php echo e(in_array($value, old($field['field'], [])) ? 'checked' : ''); ?>>
                                  <label class="form-check-label" for="<?php echo e($field['field']); ?>-<?php echo e($value); ?>">
                                      <?php echo e($label); ?>

                                  </label>
                              </div>
                          
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      
                      <?php else: ?>
                        <select class="form-control" id="<?php echo e($field['field']); ?>" name="<?php echo e($field['field']); ?>" <?php echo e($field['required'] ?? false ? 'required' : ''); ?>>
                          <option value="" selected><?php echo e($field['placeholder']); ?></option>
                          <?php $__currentLoopData = $field['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($value); ?>"><?php echo e($label); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      <?php endif; ?>
                      
                    </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                    <div class="col-md-12 text-right">
                      <button type="submit" id="pdfButton" class="btn btn-danger">Export to PDF</button>
                      <button type="submit" id="filterBtn" class="btn btn-primary">Preview Filter</button>
                    </div>
                  </form>
                </div>
                <!-- /.card-body -->
              </div>
              <!-- /.card -->
        </div>
          <?php endif; ?>
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title"><?php echo e($title ?? env('APP_NAME')); ?></h3>
                
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table class="table" id="laravel_datatable">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <?php $__currentLoopData = $grid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th><?php echo e($item['label']); ?></th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    </thead>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->

</div>



<script type="text/javascript">
    $(document).ready(function () {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $('#filterBtn').click(function(e) {
            e.preventDefault();
            $('#laravel_datatable').DataTable().ajax.reload();
        });


        $('#laravel_datatable').DataTable({
            processing: true,
            serverSide: true,
            ajax: {
                url: '<?php echo e(route($route . '.index')); ?>',
                type: 'GET',
                dataType: 'json',
                data: function (d) {
                    d.filter = {};
                    <?php $__currentLoopData = $form; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($field['type'] === 'checkbox'): ?>
                          d.filter.<?php echo e($field['field']); ?> = $('input[name="<?php echo e($field['field']); ?>[]"]:checked').map(function() {
                              return this.value;
                          }).get();
                      <?php else: ?>
                          d.filter.<?php echo e($field['field']); ?> = $('#<?php echo e($field['field']); ?>').val();
                      <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                },
                error: function (xhr, status, error) {
                    console.error('AJAX Error: ' + status + error);
                }
            },
            columns: [
              {
                data: 'id',
                name: 'id',
                render: function (data, type, row, meta) {
                    return meta.row + 1;
                }
              },
              <?php $__currentLoopData = $grid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  {data: '<?php echo e($field['field']); ?>', name: '<?php echo e($field['field']); ?>'},
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
            ],
            order: [[0, 'desc']],
            responsive: true,
            scrollX: true,
        });

        $('#pdfButton').click(function (event) {
            // Mencegah form submission default
            event.preventDefault();

            // Menyembunyikan tombol PDF
            $('#pdfButton').text('Exporting...');
            
            // Kirim request AJAX
            $.ajax({
                url: '<?php echo e(route($route . '.exportPdf')); ?>',
                type: 'POST',
                data: {
                    filter: (function() {
                        var filterData = {};
                        <?php $__currentLoopData = $form; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($field['type'] === 'checkbox'): ?> 
                                filterData['<?php echo e($field['field']); ?>'] = $('input[name="<?php echo e($field['field']); ?>[]"]:checked').map(function() {
                                    return this.value;
                                }).get();
                            
                            <?php else: ?> 
                                filterData['<?php echo e($field['field']); ?>'] = $('#<?php echo e($field['field']); ?>').val();
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        return filterData;
                    })()
                },
                success: function (response) {
                    $('#pdfButton').text('Export to PDF');

                    if (response.status === 'success') {
                        // Redirect ke URL file PDF untuk diunduh
                        window.open(response.url, '_blank');
                    }
                },
                error: function (xhr, status, error) {
                  $('#pdfButton').text('Export to PDF');

                    alert('Terjadi kesalahan: ' + error);
                }
            });
        });

    })
</script>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mangg/Documents/pdam-bumdes/resources/views/laporans/index.blade.php ENDPATH**/ ?>