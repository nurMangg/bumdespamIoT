<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <title><?php echo e($title ?? env('APP_NAME')); ?></title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            padding: 10px;
        }
        .header {
            display: flex;
            align-items: center;
            justify-content: flex-start;
            margin-bottom: 5px;
        }
        .header img {
            height: 130px;
            width: 130px;
            margin-right: 20px;
        }
        .header h3,
        .header h4 {
            margin: 0;
        }
        .header h3 {
            font-size: 1.2em;
            font-weight: bold;
        }
        .header h4 {
            font-size: 1em;
            font-weight: normal;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 0 auto;
            box-shadow: 0 2px 3px rgba(0,0,0,0.1);
        }
        th, td {
            border: none;
            padding: 12px;
            text-align: left;
            background-color: #fff;
            border-bottom: 1px solid #ddd;
            font-size: 12px;
        }
        th {
            background-color: #608BC1;
            color: #fff;
            font-weight: bold;
            
        }
        tbody tr:nth-child(odd) {
            background-color: #f9f9f9;
        }
        tfoot {
            font-weight: bold;
            background-color: #f4f4f9;
        }
        .footer {
            text-align: left;
            margin-top: 30px;
            font-size: 0.9em;
            color: #555;
        }
    </style>
</head>
<body>
    <div class="header">
        <img src="<?php echo e(public_path('images/logo.png')); ?>" alt="Logo">
        <div>
            <h3>Pagar Sejahtera | PDAM BUMDES</h3>
            <h4><?php echo e($title ?? env('APP_NAME')); ?></h4><br>
            <table style="border-collapse: collapse; border: none;">
                <tr>
                    <td style="border: none;" width="100">Tanggal</td>
                    <td style="border: none;">: <?php echo e($filterTanggal ?? 'Semua Tanggal'); ?></td>
                </tr>
                <tr>
                    <td style="border: none;" width="100">Pelanggan</td>
                    <td style="border: none;">: <?php echo e($filterKasir ?? 'Semua Kasir'); ?></td>
                </tr>
            </table>
        </div>
    </div>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <?php $__currentLoopData = $grid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th><?php echo e($item['label']); ?></th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <?php $__currentLoopData = $grid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemgrid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($itemgrid['field'] == 'pelangganBergabung'): ?>
                            <td><?php echo e(\Carbon\Carbon::parse($item->created_at)->format('d F Y H:i')); ?></td>
                        <?php else: ?>
                            <td>
                                <?php if(isset($item->{$itemgrid['field']})): ?>
                                    <?php echo e($item->{$itemgrid['field']}); ?>

                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <br>
    <table>
        <tr>
            <td colspan="2"><b>Jumlah Data</b></td>
        </tr>
        <tr>
            <td>Tagihan Belum Lunas</td>
            <td><?php echo e($dataJumlah['jumlahBelumLunas']); ?></td>
        </tr>
        <tr>
            <td>Tagihan Lunas</td>
            <td><?php echo e($dataJumlah['jumlahLunas']); ?></td>
        </tr>
        <tr>
            <td>Jumlah Tagihan Belum Lunas</td>
            <td>Rp. <?php echo e(number_format($dataJumlah['totalSemuaTagihanBelumLunas'], 0, ',', '.')); ?></td>
        </tr>
        <tr>
            <td>Jumlah Tagihan Lunas</td>
            <td>Rp. <?php echo e(number_format($dataJumlah['totalSemuaTagihanLunas'], 0, ',', '.')); ?></td>
        </tr>
    </table>
    <div class="footer">
        Dicetak pada : <?php echo e(\Carbon\Carbon::now()->format('d F Y H:i')); ?>

    </div>
</body>
</html>

<?php /**PATH /home/mangg/Documents/pdam-bumdes/resources/views/laporans/pdf/index.blade.php ENDPATH**/ ?>