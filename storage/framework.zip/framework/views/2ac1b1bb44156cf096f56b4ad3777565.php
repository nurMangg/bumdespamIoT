<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-left">
                <li class="breadcrumb-item"><a href="#"><?php echo e($breadcrumb ?? env('APP_NAME')); ?></a></li>
                <li class="breadcrumb-item active"><?php echo e($title ?? env('APP_NAME')); ?></li>
              </ol>
          </div><!-- /.col -->
          <div class="col-sm-6">
            
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
    <!-- Main content -->
    <section class="content">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Update Setting Web</h3>
                
                <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                      <i class="fas fa-minus"></i>
                    </button>
                    <button type="button" class="btn btn-tool" onclick="location.reload()" title="Refresh">
                      <i class="fas fa-sync-alt"></i>
                    </button>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <form id="addForm" name="addForm" class="form-horizontal">
                    <div class="row">
                    <input type="hidden" name="id" id="id">
                    <?php $__currentLoopData = $form; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-group col-md-<?php echo e($field['width'] ?? 12); ?>">
                            <label for="<?php echo e($field['field']); ?>" class="mb-0 control-label ">
                                <?php echo e($field['label']); ?>

                                <?php if($field['required'] ?? false): ?>
                                    <span class="text-danger">*</span>
                                <?php endif; ?>
                            </label>
                            <?php if($field['type'] === 'file'): ?>
                                <input type="file" class="form-control" id="<?php echo e($field['field']); ?>" name="<?php echo e($field['field']); ?>" value="<?php echo e(old($field['field'], $data->{$field['field']} ?? '')); ?>" <?php echo e($field['required'] ?? false ? 'required' : ''); ?> <?php echo e($field['disabled'] ?? false ? 'disabled' : ''); ?>>
                            <?php elseif($field['type'] === 'password'): ?>
                                <input type="password" class="form-control" id="<?php echo e($field['field']); ?>" name="<?php echo e($field['field']); ?>" placeholder="<?php echo e($field['placeholder'] ?? ''); ?>" value="<?php echo e(old($field['field'], $data->{$field['field']} ?? '')); ?>" <?php echo e($field['required'] ?? false ? 'required' : ''); ?> <?php echo e($field['disabled'] ?? false ? 'disabled' : ''); ?>>
                            <?php elseif($field['type'] === 'email'): ?>
                                <input type="email" class="form-control" id="<?php echo e($field['field']); ?>" name="<?php echo e($field['field']); ?>" placeholder="<?php echo e($field['placeholder'] ?? ''); ?>" value="<?php echo e(old($field['field'], $data->{$field['field']} ?? '')); ?>" <?php echo e($field['required'] ?? false ? 'required' : ''); ?> <?php echo e($field['disabled'] ?? false ? 'disabled' : ''); ?>>
                            <?php else: ?>
                                <input type="text" class="form-control" id="<?php echo e($field['field']); ?>" name="<?php echo e($field['field']); ?>" placeholder="<?php echo e($field['placeholder'] ?? ''); ?>" value="<?php echo e(old($field['field'], $data->{$field['field']} ?? '')); ?>" <?php echo e($field['required'] ?? false ? 'required' : ''); ?> <?php echo e($field['disabled'] ?? false ? 'disabled' : ''); ?>>
                            <?php endif; ?>
                            <span class="text-danger" id="<?php echo e($field['field']); ?>Error"></span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </div>
                    <div class="col-sm-12 mt-3 d-flex justify-content-end">
                        <button type="submit" class="btn <?php echo e($color ?? 'btn-blue'); ?>" id="saveBtn" value="create">Simpan Data</button>
                    </div>
                </form>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->

</div>

<script type="text/javascript">
    $(document).ready(function () {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });


        $('#saveBtn').click(function (e) {
            e.preventDefault();
            $('#saveBtn').html('Mengirim..');

            // Reset error messages
            <?php $__currentLoopData = $form; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                $('#<?php echo e($field["field"]); ?>Error').text('');
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            // Ajax request
            $.ajax({
                data: new FormData($('#addForm')[0]),
                url: "<?php echo e(route($route . '.store')); ?>",
                type: "POST",
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function (response) {
                    $('#ajaxModel').modal('hide');
                    $('#saveBtn').html('Simpan Data');

                    toastr.success(response.success || "Data berhasil disimpan!");
                },
                error: function (xhr) {
                    $('#saveBtn').html('Simpan Data');

                    if (xhr.status === 422) {
                        // Tampilkan error validasi
                        var errors = xhr.responseJSON.errors;
                        for (const field in errors) {
                            $(`#${field}Error`).text(errors[field][0]);
                        }

                        toastr.error("Terdapat error validasi. Silakan periksa form.");
                    } else {
                        // Error selain validasi
                        toastr.error(xhr.responseJSON.error || "Terjadi kesalahan sistem.");
                    }
                }
            });
        });

            


    })
</script>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mangg/Documents/pdam-bumdes/resources/views/setting/index.blade.php ENDPATH**/ ?>