<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-left">
                <li class="breadcrumb-item"><a href="#"><?php echo e($breadcrumb ?? env('APP_NAME')); ?></a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('tagihan.index')); ?>"><?php echo e($title ?? env('APP_NAME')); ?></a></li>
                <li class="breadcrumb-item active"><?php echo e($detailPelanggan->pelangganKode ?? ' -'); ?></li>
              </ol>
          </div><!-- /.col -->
          <div class="col-sm-6">
            
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content pb-5">
        <div class="container mb-3">
            
        </div>
      <div class="container">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title"><?php echo e(__('Detail Pelanggan')); ?></h3>
                <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                      <i class="fas fa-minus"></i>
                    </button>
                    <button type="button" class="btn btn-tool" onclick="location.reload()" title="Refresh">
                      <i class="fas fa-sync-alt"></i>
                    </button>
                </div>
                
              </div>
              <!-- /.card-header -->
              <div class="card-body" id="collapseExample">
                <div class="row">
                    <div class="col-md-6">
                        <h6>Informasi Pelanggan</h6>
                        <table id="tagihanDetailsTable" class="table table-hover">
                            <colgroup>
                                <col style="width: 30%;">
                                <col style="width: 70%;">
                            </colgroup>
                            <tr>
                                <td>Kode Pelanggan</td>
                                <td>&emsp;&emsp;: <span
                                        id="detailPelangganKode"><?php echo e($detailPelanggan->pelangganKode ?? ' -'); ?></span></td>
                            </tr>
                            <tr>
                                <td>Nama</td>
                                <td>&emsp;&emsp;: <span id="detailPelangganNama"><?php echo e($detailPelanggan->pelangganNama ?? ' -'); ?></span></td>
                            </tr>
                            <tr>
                                <td>Nomor Hp</td>
                                <td>&emsp;&emsp;: <span
                                        id="detailPelangganPhone"><?php echo e($detailPelanggan->pelangganPhone ?? ' -'); ?></span></td>
                            </tr>
                            <tr>
                                <td>Alamat</td>
                                <td>&emsp;&emsp;: <span id="detailPelangganAlamat"><?php echo e('RT ' . $detailPelanggan->pelangganRt . '/' . 'RW ' . $detailPelanggan->pelangganRw  ?? ' -'); ?></span></td>
                            </tr>
                            <tr>
                                <td>Golongan Tarif</td>
                                <td>&emsp;&emsp;: <span
                                        id="detailPelangganGolonganNama"><?php echo e($detailPelanggan->golongan->golonganNama ?? ' -'); ?></span>
                                </td>
                            </tr>

                        </table>
                    </div>
                    <div class="col-md-6">
                        <h6>Informasi Tarif Harga</h6>
                        <table id="tagihanDetailsTable2" class="table table-hover">
                            <colgroup>
                                <col style="width: 30%;">
                                <col style="width: 70%;">
                            </colgroup>
                            <tr>
                                <td>Tarif Harga</td>
                                <td>&emsp;&emsp;: <span
                                        id="detailPelangganGolonganHarga">Rp. <?php echo e(number_format($detailPelanggan->golongan->golonganTarif ?? 0, 0, ',', '.')); ?></span></td>
                            </tr>
                            <tr>
                                <td>Tarif Denda</td>
                                <td>&emsp;&emsp;: <span id="detailPelangganGolonganDenda">Rp. <?php echo e(number_format($detailPelanggan->golongan->golonganAbonemen ?? 0, 0, ',', '.')); ?></span></td>
                            </tr>
                        </table>
                        <h6>Informasi Penggunaan</h6>
                        <table id="tagihanDetailsTable3" class="table table-hover">
                            <colgroup>
                                <col style="width: 30%;">
                                <col style="width: 70%;">
                            </colgroup>
                            <tr>
                                <td>Penggunaan Air</td>
                                <td>&emsp;&emsp;: <span
                                        id="detailPelangganGolonganHarga"><?php echo e($penggunaanTagihan->tagihanMAkhir ?? ' -'); ?> m3</span></td>
                            </tr>
                            <tr>
                                <td>Total Tagihan Kemarin</td>
                                <td>&emsp;&emsp;: <span id="detailPelangganTotalTagihan">Rp. <?php echo e(number_format($penggunaanTagihan->totalTagihan ?? 0, 0, ',', '.')); ?></span></td>
                            </tr>
                        </table>
                    </div>
                </div>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>


      
      <div class="container mb-3 mt-5">
        <div class="row">
            <div class="col-md-6">
                <?php if($jumlahTagihanBelumLunas >= 3 && $detailPelanggan->pelangganPhone): ?>
                    <button id="kirimPeringatan" data-id="<?php echo e(Crypt::encryptString($detailPelanggan->pelangganKode) ?? ' -'); ?>" class="btn btn-warning" style="color: #ffffff" onclick="kirimPeringatan()"><i class="fas fa-bell"></i> Kirim Peringatan</button>
                <?php else: ?>
                    <button class="btn btn-warning" style="color: #ffffff" disabled><i class="fas fa-bell"></i> Kirim Peringatan</button>
                <?php endif; ?>
            </div>
            <div class="col-md-6">
                <div class="float-sm-right">
                    <button id="create" class="btn" style="background-color: #608BC1; color: #ffffff">
                        Tambah <?php echo e($title ?? env('APP_NAME')); ?>

                    </button>
                </div>
                
            </div>
        </div>
        </div>
      <div class="container">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Daftar <?php echo e(__('Data Tagihan Pelanggan')); ?></h3>
                <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                      <i class="fas fa-minus"></i>
                    </button>
                    
                  </div>
                
              </div>
              <!-- /.card-header -->
              <div class="card-body" id="collapseExample">
                <table class="table" id="laravel_datatable">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <?php $__currentLoopData = $form; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th><?php echo e($item['label']); ?></th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <th>Jumlah Tagihan</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->

</div>

<?php if (isset($component)) { $__componentOriginal2de41bd58e79fb25b173007b6f0eaf19 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2de41bd58e79fb25b173007b6f0eaf19 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.modal','data' => ['form' => $form,'title' => $title ?? env('APP_NAME')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['form' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($form),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($title ?? env('APP_NAME'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2de41bd58e79fb25b173007b6f0eaf19)): ?>
<?php $attributes = $__attributesOriginal2de41bd58e79fb25b173007b6f0eaf19; ?>
<?php unset($__attributesOriginal2de41bd58e79fb25b173007b6f0eaf19); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2de41bd58e79fb25b173007b6f0eaf19)): ?>
<?php $component = $__componentOriginal2de41bd58e79fb25b173007b6f0eaf19; ?>
<?php unset($__componentOriginal2de41bd58e79fb25b173007b6f0eaf19); ?>
<?php endif; ?>

<script type="text/javascript">
    $(document).ready(function () {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });


        $('#laravel_datatable').DataTable({
            processing: true,
            serverSide: true,
            ajax: {
                url: '<?php echo e(route($route . '.index')); ?>',
                data: {
                    pelangganKode: "<?php echo e($detailPelanggan->pelangganKode ?? ''); ?>"
                },

                type: 'GET',
                dataType: 'json',
                error: function (xhr, status, error) {
                    console.error('AJAX Error: ' + status + error);
                }
            },
            columns: [
              {
                data: 'id',
                name: 'id',
                render: function (data, type, row, meta) {
                    return meta.row + 1;
                }
              },
              <?php $__currentLoopData = $form; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  {data: '<?php echo e($field['field']); ?>', name: '<?php echo e($field['field']); ?>'},
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              {data: 'tagihanJumlah', name: 'tagihanJumlah'},
              {data: 'action', name: 'action', orderable: false, searchable: false},
            ],
            order: [[0, 'desc']],
            responsive: true,
            scrollX: true,
        });

        $('#create').click(function () {
            $('#saveBtn').val("create-action");
            $('#id').val('');
            $('#addForm').trigger("reset");
            $('#modelHeading').html("Tambah Baru <?php echo e($title ?? env('APP_NAME')); ?>");
            $('#ajaxModel').modal('show');
            $('#tagihanMAwal').val('<?php echo e(($penggunaanTagihan->tagihanMAkhir ?? 0) + 1); ?>')
        });

        $('body').on('click', '.edit', function () {
            var id = $(this).data('id');
            $.get('<?php echo e(route($route . '.index')); ?>/' + id + '/edit', function (data) {
                $('#modelHeading').html("Edit <?php echo e($title ?? env('APP_NAME')); ?>");
                $('#saveBtn').val("edit-action");
                $('#ajaxModel').modal('show');
                $('#id').val(id);
                <?php $__currentLoopData = $form; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    $('#<?php echo e($field['field']); ?>').val(data.<?php echo e($field['field']); ?>);
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            })
        });

        $('body').on('click', '#kirimPeringatan', function () {
            var id = $(this).data('id');
            $('#kirimPeringatan').html('Processing...').prop('disabled', true);

            $.get(`<?php echo e(route('tagihan.aksi-tagihan.kirim-peringatan', [ 'id' => ':id' ])); ?>`.replace(':id', id), function (data) {
                if (data.success) {
                    $('#kirimPeringatan').html('Kirim Peringatan').prop('disabled', false);
                    toastr.success(data.message);
                } else {
                    $('#kirimPeringatan').html('Kirim Peringatan').prop('disabled', false);
                    toastr.error(data.message);
                }
            }).fail(function(xhr, status, error) {
                $('#kirimPeringatan').html('Kirim Peringatan').prop('disabled', false);
                // toastr.error(xhr.responseText);
                toastr.error('Terjadi kesalahan saat mengirim peringatan.');

            })
        });


        $('#saveBtn').click(function (e) {
            e.preventDefault();
            $('#saveBtn').html('Mengirim..');

            // Reset error messages
            <?php $__currentLoopData = $form; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($field['required'] ?? false): ?>
                    $('#<?php echo e($field['field']); ?>Error').text('');
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            // Validate non-empty fields
            var isValid = true;
            <?php $__currentLoopData = $form; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($field['required'] ?? false): ?>
                    if (!$('#<?php echo e($field['field']); ?>').val()) {
                        $('#<?php echo e($field['field']); ?>Error').text('This field is required.');
                        isValid = false;
                    }
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            if (!isValid) {
                $('#saveBtn').html('Simpan Data');
                return;
            }

            var actionType = $(this).val();
            console.log(actionType);
            var url = actionType === "create-action" ? "<?php echo e(route($route . '.store')); ?>" :
                "<?php echo e(route($route . '.index')); ?>/" + $('#id').val();

            // Tentukan jenis permintaan (POST atau PUT)
            var requestType = actionType === "create-action" ? "POST" : "PUT";

            $.ajax({
                data: $('#addForm').serialize() + "&pelangganId=" + "<?php echo e($detailPelanggan->pelangganId ?? ''); ?>",
                url: url,
                type: requestType,
                dataType: 'json',
                success: function (data) {
                    $('#addForm').trigger("reset");
                    $('#ajaxModel').modal('hide');
                    $('#laravel_datatable').DataTable().ajax.reload();
                    $('#saveBtn').html('Simpan Data');

                    var message = actionType === "create-action" ? "Data Berhasil ditambahkan!" : "Data berhasil diperbarui!";
                    toastr.success(message);
                },
                error: function (xhr) {
                    $('#saveBtn').html('Simpan Data');

                    if (xhr.status === 422) {
                        var errors = xhr.responseJSON.errors;
                        <?php $__currentLoopData = $form; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($field['required'] ?? false): ?>
                                if (errors.<?php echo e($field['field']); ?>) {
                                    $('#<?php echo e($field['field']); ?>Error').text(errors.<?php echo e($field['field']); ?>);
                                }
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    } else {
                      toastr.error('Terjadi kesalahan saat menyimpan data.');
                    }
                }
            });
        });

        $('body').on('click', '.delete', function () {
            var id = $(this).data('id');
            Swal.fire({
                title: 'Anda yakin?',
                text: "Apakah Anda yakin ingin menghapus data ini?",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Ya, hapus!'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        type: "DELETE",
                        url: "<?php echo e(route($route . '.index')); ?>/" + id,
                        success: function (data) {
                            $('#laravel_datatable').DataTable().ajax.reload();
                            toastr.success('Data berhasil dihapus!');
                        },
                        error: function (data) {
                            console.log('Error:', data);
                            toastr.error('Terjadi kesalahan saat menghapus data.');
                        }
                    });
                }
            });
        });
            


    })
</script>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mangg/Documents/pdam-bumdes/resources/views/layanans/detail.blade.php ENDPATH**/ ?>