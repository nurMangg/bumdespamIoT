<form id="<?php echo e($name ?? "addForm"); ?>" name="<?php echo e($name ?? "addForm"); ?>" class="form-horizontal">
    <div class="row">
    <input type="hidden" name="id" id="id">
    <?php $__currentLoopData = $form; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="form-group col-md-<?php echo e($field['width'] ?? 12); ?>">
            <label for="<?php echo e($field['field']); ?>" class="mb-0 control-label">
                <?php echo e($field['label']); ?>

                <?php if($field['required'] ?? false): ?>
                    <span class="text-danger">*</span>
                <?php endif; ?>
            </label>
            <?php if($field['type'] === 'textarea'): ?>
                <textarea class="form-control" id="<?php echo e($field['field']); ?>" name="<?php echo e($field['field']); ?>" placeholder="<?php echo e($field['placeholder'] ?? ''); ?>" <?php echo e($field['required'] ?? false ? 'required' : ''); ?> <?php echo e($field['disabled'] ?? false ? 'disabled' : ''); ?>></textarea>
            <?php elseif($field['type'] === 'file'): ?>
                <input type="file" class="form-control" id="<?php echo e($field['field']); ?>" name="<?php echo e($field['field']); ?>" <?php echo e($field['required'] ?? false ? 'required' : ''); ?> <?php echo e($field['disabled'] ?? false ? 'disabled' : ''); ?>>
            <?php elseif($field['type'] === 'password'): ?>
                <input type="password" class="form-control" id="<?php echo e($field['field']); ?>" name="<?php echo e($field['field']); ?>" placeholder="<?php echo e($field['placeholder'] ?? ''); ?>" <?php echo e($field['required'] ?? false ? 'required' : ''); ?> <?php echo e($field['disabled'] ?? false ? 'disabled' : ''); ?>>
            <?php elseif($field['type'] === 'email'): ?>
                <input type="email" class="form-control" id="<?php echo e($field['field']); ?>" name="<?php echo e($field['field']); ?>" placeholder="<?php echo e($field['placeholder'] ?? ''); ?>" <?php echo e($field['required'] ?? false ? 'required' : ''); ?> <?php echo e($field['disabled'] ?? false ? 'disabled' : ''); ?>>
            <?php elseif($field['type'] === 'number'): ?>
                <input type="number" class="form-control" id="<?php echo e($field['field']); ?>" name="<?php echo e($field['field']); ?>" placeholder="<?php echo e($field['placeholder'] ?? ''); ?>" <?php echo e($field['required'] ?? false ? 'required' : ''); ?> <?php echo e($field['disabled'] ?? false ? 'disabled' : ''); ?>>
            <?php elseif($field['type'] === 'date'): ?>
                <input type="date" class="form-control" id="<?php echo e($field['field']); ?>" name="<?php echo e($field['field']); ?>" placeholder="<?php echo e($field['placeholder'] ?? ''); ?>" <?php echo e($field['required'] ?? false ? 'required' : ''); ?> <?php echo e($field['disabled'] ?? false ? 'disabled' : ''); ?>>
            <?php elseif($field['type'] === 'select'): ?>
                <select class="form-control" id="<?php echo e($field['field']); ?>" name="<?php echo e($field['field']); ?>" <?php echo e($field['required'] ?? false ? 'required' : ''); ?>>
                    <option value="" disabled selected><?php echo e($field['placeholder'] ?? ''); ?></option>
                    <?php $__currentLoopData = $field['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($value); ?>" <?php echo e(old($field['field'], $field['default'] ?? '') == $value ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            <?php elseif($field['type'] === 'checkbox'): ?>
            <div class="row ms-3 mt-2">
                <?php $__currentLoopData = $field['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                    <div class="col-md-3 form-check">
                        <input class="form-check-input" type="checkbox" id="<?php echo e($field['field']); ?>-<?php echo e($value); ?>" name="<?php echo e($field['field']); ?>[]" value="<?php echo e($value); ?>" <?php echo e(in_array($value, old($field['field'], [])) ? 'checked' : ''); ?>>
                        <label class="form-check-label" for="<?php echo e($field['field']); ?>-<?php echo e($value); ?>">
                            <?php echo e($label); ?>

                        </label>
                    </div>
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php else: ?>
                <input type="text" class="form-control" id="<?php echo e($field['field']); ?>" name="<?php echo e($field['field']); ?>" placeholder="<?php echo e($field['placeholder'] ?? ''); ?>" <?php echo e($field['required'] ?? false ? 'required' : ''); ?> <?php echo e($field['disabled'] ?? false ? 'disabled' : ''); ?>>
            <?php endif; ?>
            <span class="text-danger" id="<?php echo e($field['field']); ?>Error"></span>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</form><?php /**PATH /home/mangg/Documents/pdam-bumdes/resources/views/components/form/nomodalbutton.blade.php ENDPATH**/ ?>