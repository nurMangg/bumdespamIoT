<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-left">
                <li class="breadcrumb-item"><a href="#"><?php echo e($breadcrumb ?? env('APP_NAME')); ?></a></li>
                <li class="breadcrumb-item active"><?php echo e($title ?? env('APP_NAME')); ?></li>
              </ol>
          </div><!-- /.col -->
          <div class="col-sm-6">
            
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
        <div class="container mb-3">
            
        </div>
      <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                      <h3 class="card-title"><?php echo e($title ?? env('APP_NAME')); ?></h3>
                      
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">
                      <div class="mb-5">
                        <h5>Contoh Format Data</h5>
                        <img src="<?php echo e(asset($image ?? '' )); ?>" alt="" width="100%">
                        <small style="color:red">*</small> Pastikan format data sesuai dengan contoh
                        <br>
                        <small style="color:red">*</small> Pastikan header data sesuai dengan contoh
                      </div>
                      
                      <form id="importData" name="importData" enctype="multipart/form-data">
                        <div class="row">
                        <?php $__currentLoopData = $form; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mb-3 col-md-<?php echo e($field['width'] ?? 12); ?>">
                          <label for="<?php echo e($field['field']); ?>" class="control-label">
                              <?php echo e($field['label']); ?>

                          </label>
          
                          <input type="file" class="form-control" id="<?php echo e($field['field']); ?>" name="<?php echo e($field['field']); ?>" <?php echo e($field['required'] ?? false ? 'required' : ''); ?> <?php echo e($field['disabled'] ?? false ? 'disabled' : ''); ?>>
                          <span class="text-danger" id="<?php echo e($field['field']); ?>Error"></span>
                        </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </div>
                        <div class="col-md-12 text-right">
                          <button type="submit" id="importBtn" class="btn btn-primary"><?php echo e($title ?? env('APP_NAME')); ?></button>
                        </div>
                      </form>
                    </div>
                    <!-- /.card-body -->
                  </div>
                  <!-- /.card -->
            </div>
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->

</div>

<script type="text/javascript">
    $(document).ready(function () {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $('#importBtn').click(function (e) {
            e.preventDefault();
            var formData = new FormData($('#importData')[0]);
            $('#importBtn').html('Mengirim..');

            <?php $__currentLoopData = $form; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($field['required'] ?? false): ?>
                    $('#<?php echo e($field['field']); ?>Error').text('');
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            $.ajax({
                type: 'POST',
                url: "<?php echo e(route($route . '.store')); ?>",
                data: formData,
                contentType: false,
                processData: false,
                success: function (data) {
                    $('#importData').trigger("reset");
                    $('#importBtn').html('<?php echo e($title ?? env('APP_NAME')); ?>');
                    toastr.success('Data berhasil diimport!');
                },
                error: function (xhr) {
                  $('#importBtn').html('<?php echo e($title ?? env('APP_NAME')); ?>');

                  if (xhr.status === 422) { 
                      var errors = xhr.responseJSON.errors;
                      <?php $__currentLoopData = $form; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if($field['required'] ?? false): ?>
                              if (errors.<?php echo e($field['field']); ?>) {
                                  $('#<?php echo e($field['field']); ?>Error').text(errors.<?php echo e($field['field']); ?>);
                              }
                          <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  } else {
                    toastr.error('Terjadi kesalahan saat menyimpan data.');
                  }
                }
            });
        });

    })
</script>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mangg/Documents/pdam-bumdes/resources/views/imports/index.blade.php ENDPATH**/ ?>