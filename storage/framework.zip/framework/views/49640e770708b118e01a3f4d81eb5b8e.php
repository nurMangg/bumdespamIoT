Attached you will find requested report.
<?php /**PATH /home/mangg/Documents/pdam-bumdes/vendor/yajra/laravel-datatables-export/src/resources/views/export-email.blade.php ENDPATH**/ ?>