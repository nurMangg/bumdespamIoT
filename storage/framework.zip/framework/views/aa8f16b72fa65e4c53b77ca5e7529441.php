<?php 
  $totalPelanggan = \App\Models\Pelanggan::all()->count();
  $totalTagihan = \App\Models\Tagihan::all()->count();

  $tagihan = \App\Models\Tagihan::whereNull('deleted_at')->get();
  $tagihanLimit4 = \App\Models\Tagihan::orderBy('tagihanId', 'desc')->limit(4)->get();
  
  $tagihan->transform(function($item) {
      $item->tagihanTotal = ($item->tagihanMAkhir - $item->tagihanMAwal) * $item->tagihanInfoTarif;
      $item->tagihanJumlahTotal = $item->tagihanTotal + $item->tagihanInfoAbonemen;
      return $item;
  });

  $totalSemuaTagihanBelumLunas = $tagihan->whereIn('tagihanStatus', ['Pending', 'Belum Lunas'])->sum('tagihanJumlahTotal');
  $totalSemuaTagihanLunas = $tagihan->where('tagihanStatus', 'Lunas')->sum('tagihanJumlahTotal');

  //Transaksi tabel
  function fetchTagihanByStatus(array $statuses)
  {
      return DB::table('tagihans')
          ->join('msbulan', 'tagihans.tagihanBulan', '=', 'msbulan.bulanId')
          ->selectRaw('
              CONCAT(msbulan.bulanNama, " ", tagihanTahun) as bulanTahun,
              SUM((tagihans.tagihanMAkhir - tagihans.tagihanMAwal) * tagihans.tagihanInfoTarif + tagihans.tagihanInfoAbonemen) as totalJumlah
          ')
          ->whereNull('tagihans.deleted_at')
          ->whereIn('tagihanStatus', $statuses)
          ->groupBy('bulanTahun')
          ->orderByRaw('tagihanTahun, tagihanBulan')
          ->pluck('totalJumlah', 'bulanTahun');
  }

  // Retrieve data for each status
  $tagihanByMonthLunas = fetchTagihanByStatus(['Lunas']);
  $tagihanByMonthBelumLunas = fetchTagihanByStatus(['Pending', 'Belum Lunas']);

  // Merge keys for all months and sort them
  $allMonths = $tagihanByMonthLunas->keys()
    ->merge($tagihanByMonthBelumLunas->keys())
    ->unique()
    ->sort(function ($a, $b) {
        // Extract year and month from "NamaBulan Tahun" format
        [$monthA, $yearA] = explode(' ', $a);
        [$monthB, $yearB] = explode(' ', $b);

        $monthOrder = [
            'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
            'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
        ];

        // Compare by year first, then by month order
        return ($yearA <=> $yearB) ?: (array_search($monthA, $monthOrder) <=> array_search($monthB, $monthOrder));
    });

  // Prepare labels and datasets
  $labels = $allMonths->values();
  $dataLunas = $labels->map(fn($bulanTahun) => $tagihanByMonthLunas->get($bulanTahun, 0));
  $dataBelumLunas = $labels->map(fn($bulanTahun) => $tagihanByMonthBelumLunas->get($bulanTahun, 0));

  // Data Pelanggan PIE CHART
  $dataPelanggan = \App\Models\Pelanggan::selectRaw("CONCAT('RW ', pelangganRw) as pelangganDesa, COUNT(*) as total")
    ->groupBy('pelangganDesa')
    ->get();

    $backgroundColor = [
        '#f56954', '#00a65a', '#f39c12', '#00c0ef', '#3c8dbc', '#d2d6de',
        '#39cccc', '#001f3f', '#85144b', '#f012be', '#b10dc9', '#ff851b',
        '#ff4136', '#2ecc40', '#3d9970', '#111111', '#aaaaaa', '#dddddd',
        '#ff851b', '#7fdbff', '#39cccc', '#3b9dcd', '#01ff70', '#ffdc00',
        '#ff851b', '#bada55', '#ff69b4', '#ff6347', '#ffa500', '#8a2be2'
    ];

    $dataPelangganChart = $dataPelanggan->map(function($item, $index) use ($backgroundColor) {
        return [
            'label' => $item->pelangganDesa,
            'backgroundColor' => $backgroundColor[$index % count($backgroundColor)],
            'data' => [$item->total]
        ];
    })->toArray();


?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Dashboard</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Dashboard</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->

        <div class="row">
          <?php if(Hash::check('password', Auth::user()->password)): ?>
          <div class="col-12">
            <div class="alert alert-danger alert-dismissible">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              <h5><i class="icon fas fa-exclamation-triangle"></i> Peringatan!</h5>
              Anda masih menggunakan password default, silakan ubah password default Anda</a>.
            </div>
          </div>
          <?php endif; ?>
          <div class="col-12 col-sm-6 col-md-3">
            <div class="info-box">
              <span class="info-box-icon bg-info elevation-1"><i class="fas fa-user"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">Total Pelanggan</span>
                <span class="info-box-number">
                  <?php echo e($totalPelanggan); ?>

                  <small></small>
                </span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
          <div class="col-12 col-sm-6 col-md-3">
            <div class="info-box mb-3">
              <span class="info-box-icon bg-danger elevation-1"><i class="fas fa-file-invoice"></i></span>

              <div class="info-box-content">
                <span class="info-box-text" data-toggle="tooltip" data-placement="top" title="Total tagihan yang belum dibayar">Total Tagihan</span>
                <span class="info-box-number"><?php echo e($totalTagihan); ?></span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->

          <!-- fix for small devices only -->
          <div class="clearfix hidden-md-up"></div>

          <div class="col-12 col-sm-6 col-md-3">
            <div class="info-box mb-3">
              <span class="info-box-icon bg-warning elevation-1"><i class="fas fa-exclamation-circle"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">Tagihan Belum Lunas</span>
                <span class="info-box-number">Rp. <?php echo e(number_format($totalSemuaTagihanBelumLunas, 0, ',', '.')); ?></span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
          <div class="col-12 col-sm-6 col-md-3">
            <div class="info-box mb-3">
              <span class="info-box-icon bg-success elevation-1"><i class="fas fa-check-circle"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">Tagihan Lunas</span>
                <span class="info-box-number">Rp. <?php echo e(number_format($totalSemuaTagihanLunas, 0, ',', '.')); ?></span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
          
        </div>

        <div class="row">
          <div class="col-md-6">
            
            <!-- /.card -->

            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Jumlah Pelanggan Per Desa</h3>

                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse">
                    <i class="fas fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-tool" data-card-widget="remove">
                    <i class="fas fa-times"></i>
                  </button>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <div class="row">
                  <div class="col-md-6">
                    <div class="chart-responsive">
                      <canvas id="pieChart" height="150"></canvas>
                    </div>
                    <!-- ./chart-responsive -->
                  </div>
                  <!-- /.col -->
                  <div class="col-md-3">
                    <ul class="chart-legend clearfix">
                      <?php $__currentLoopData = array_slice($dataPelangganChart, 0, ceil(count($dataPelangganChart) / 2)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li> <i class="far fa-circle" style="color: <?php echo e($label['backgroundColor']); ?>"></i>  <?php echo e($label['label']); ?></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                  </div>
                  <div class="col-md-3">
                    <ul class="chart-legend clearfix">
                      <?php $__currentLoopData = array_slice($dataPelangganChart, ceil(count($dataPelangganChart) / 2)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li> <i class="far fa-circle" style="color: <?php echo e($label['backgroundColor']); ?>"></i>  <?php echo e($label['label']); ?></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                  </div>
                  <!-- /.col -->
                </div>
                <!-- /.row -->
              </div>
              <!-- /.card-body -->
              <div class="card-footer p-0">
                <ul class="nav nav-pills flex-column">
                  <?php $__currentLoopData = $dataPelangganChart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li class="nav-item">
                    <a href="#" class="nav-link">
                      <?php echo e($item['label']); ?>

                      <span class="float-right">
                        <?php echo e($item['data'][0]); ?>

                      </span>
                    </a>
                  </li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              </div>
              <!-- /.footer -->
            </div>
            <!-- /.card -->
          </div>

          <div class="col-md-6">
            <div class="card">
              <div class="card-header border-0">
                <h3 class="card-title">Tagihan Baru</h3>
                <div class="card-tools">
                  
                </div>
              </div>
              <div class="card-body table-responsive p-0">
                <table class="table table-striped table-valign-middle">
                  <thead>
                  <tr>
                    <th>Tagihan Kode</th>
                    <th>Nama Pelanggan</th>
                    <th>Pemakaian Air (m3)</th>
                    <th>Tagihan</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php $__currentLoopData = $tagihanLimit4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($item->tagihanKode); ?></td>
                    <td><?php echo e($item->pelanggan->pelangganNama); ?></td>
                    <td><?php echo e($item->tagihanMAwal); ?> - <?php echo e($item->tagihanMAkhir); ?> m3</td>
                    <td>Rp. <?php echo e(number_format(($item->tagihanMAkhir - $item->tagihanMAwal) * $item->tagihanInfoTarif, 0, ',', '.')); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
            </div>

            <div class="card">
              <div class="card-header border-0">
                <div class="d-flex justify-content-between">
                  <h3 class="card-title">Total Transaksi</h3>
                </div>
              </div>
              <div class="card-body">
                <div class="d-flex">
                  <p class="d-flex flex-column">
                    <span class="text-bold text-lg">Rp. <?php echo e(number_format($tagihan->sum('tagihanJumlahTotal'), 0, ',', '.')); ?> </span>
                    <span>Transaksi per Waktu</span>
                  </p>
                  
                </div>
                <!-- /.d-flex -->

                <div class="position-relative mb-4">
                  <canvas id="sales-chart" height="200"></canvas>
                </div>

                <div class="d-flex flex-row justify-content-end">
                  <span class="mr-2">
                    <i class="fas fa-square text-primary"></i> Lunas
                  </span>

                  <span>
                    <i class="fas fa-square text-gray"></i> Belum Lunas
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
</div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

<script>
  var chartLabels = <?php echo json_encode($labels, 15, 512) ?>;
  var chartDataLunas = <?php echo json_encode($dataLunas, 15, 512) ?>;
  var chartDataBelumLunas = <?php echo json_encode($dataBelumLunas, 15, 512) ?>;

  // PIE CHART
  var dataPelangganChart = <?php echo json_encode($dataPelangganChart, 15, 512) ?>;

  // Ekstrak labels dan data
  var pieLabels = dataPelangganChart.map(item => item.label);
  var pieData = dataPelangganChart.map(item => item.data[0]);
  var backgroundColors = dataPelangganChart.map(item => item.backgroundColor);

</script>
    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="<?php echo e(asset('dist/js/pages/dashboard3.js')); ?>" defer></script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mangg/Documents/pdam-bumdes/resources/views/dashboard.blade.php ENDPATH**/ ?>